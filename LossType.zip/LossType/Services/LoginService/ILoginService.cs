﻿using LossType.Domain.DTO.Requests;
using LossType.Domain.DTO.Response;
using LossType.Domnain.DTO.Response;
using System.Threading.Tasks;

namespace LossType.Services.Login
{
    public interface ILoginService
    {
        public Task<APIResponse<UserDto>> ValidateUser(LoginRequest request);
    }
}
