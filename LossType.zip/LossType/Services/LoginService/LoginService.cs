﻿using LossType.Domain.DTO.Requests;
using LossType.Domain.DTO.Response;
using LossType.Domnain.DTO.Response;
using LossType.Framework.Builders;
using LossType.Framework.JWTWebToken;
using LossType.Framework.Middleware;
using LossType.Framework.Middleware.Model;
using LossType.Repositories.Interfaces;
using Microsoft.Extensions.Localization;
using System;
using System.Net;
using System.Threading.Tasks;

namespace LossType.Services.Login
{
    public class LoginService : ILoginService
    {
        private readonly IResponseBuilderFactory _responseBuilderFactory;
        private readonly ILoginRepository _loginRepository;
        ITokenOperations _tokenOperations;
        private readonly IStringLocalizer<SharedResource> _localizer;
        public LoginService(IResponseBuilderFactory responseBuilderFactory, ILoginRepository loginRepository,
            ITokenOperations tokenOperations, IStringLocalizer<SharedResource> localizer)
        {
            _responseBuilderFactory = responseBuilderFactory;
            _loginRepository = loginRepository;
            _tokenOperations = tokenOperations;
            _localizer = localizer;
        }
        public async Task<APIResponse<UserDto>> ValidateUser(LoginRequest request)
        {
            var responseBuilder = _responseBuilderFactory.GetBuilder<UserDto>();
            request.LoginRequestReason = LoginReason.LOGIN;
            var result = await this._loginRepository.ValidateUser(request);
            if (!result.IsAllowLogin)
                throw new ApiException(new ExceptionDetails { ErrorMessage = _localizer["UserDoesNotExists"], StatusCode = HttpStatusCode.NotFound, ExceptionLevel = ExceptionLevel.Info });
            return responseBuilder.AddSuccessData(result).Build();
        }
       
    }
}

