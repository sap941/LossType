﻿using LossType.Domain.DTO.Requests;
using LossType.Framework.Base;
using LossType.Services.Login;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Client.Api.Controllers
{
    [Route("api/v1")]
    [ApiController]
    [Authorize]
    public class LoginController : BaseController
    {
        private ILoginService _loginService;
        public LoginController(ILoginService loginService)
        {
            this._loginService = loginService;
        }
       
        [AllowAnonymous]
        [HttpPost, Route("validate-user")]
        public async Task<IActionResult> ValidateClientUser([FromBody] LoginRequest loginRequest)
        {
            loginRequest.Password = string.Empty;
            var data = await _loginService.ValidateUser(loginRequest);
            return Ok(data);
        }
        
    }
}