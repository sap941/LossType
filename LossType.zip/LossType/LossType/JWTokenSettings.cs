﻿
namespace LossType
{
    public class JWTokenSettings
    {
        public int TokenExpiryTimeInMinutes { get; set; }
        public string AuthenticationKey { get; set; }
        public string AuthorizationKey { get; set; }
        public string ClientAuthorizationKey { get; set; }
    }
}
