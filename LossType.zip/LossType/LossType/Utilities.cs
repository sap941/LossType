﻿namespace LossType
{
    public class Utilities
    {
        public static string ConnectionString { get; set; }
        
       
    }

}
