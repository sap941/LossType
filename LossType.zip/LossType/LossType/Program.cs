using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using NLog;
using System;
using System.IO;

namespace LossType
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //CreateHostBuilder(args).Build().Run();
            var configuringFileName = "nlog.config";
            var aspnetEnvironment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            var environmentSpecificLogFileName = $"nlog.{aspnetEnvironment}.config";
            if (File.Exists(environmentSpecificLogFileName))
            {
                configuringFileName = environmentSpecificLogFileName;
            }
            LogFactory logFactory = new LogFactory().LoadConfiguration(configuringFileName);
            LogManager.Configuration = logFactory.Configuration;
            NLog.ILogger _logger = logFactory.GetCurrentClassLogger();
            try
            {
                _logger.Trace("Main() method starts ...");
                CreateHostBuilder(args).Build().Run();
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error occurred in Main() method !");
            }
            finally
            {
                LogManager.Shutdown();
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
