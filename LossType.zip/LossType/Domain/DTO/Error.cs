﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LossType.Domain.DTO.Error
{
    /// <summary>
    /// 
    /// </summary>
    public class Error
    {
        /// <summary>
        /// Gets or sets the user message.
        /// </summary>
        /// <value>
        /// The user message.
        /// </value>
        public string UserMessage { set; get; }

        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        public int ErrorCode { set; get; }

        /// <summary>
        /// Gets or sets the dev message.
        /// </summary>
        /// <value>
        /// The dev message.
        /// </value>
        public string DevMessage { set; get; }

        /// <summary>
        /// Gets or sets the path.
        /// </summary>
        /// <value>
        /// The path.
        /// </value>
        public string Path { set; get; }
    }
}
