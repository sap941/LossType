﻿using System;

namespace LossType.Domain.DTO.Requests
{
    public class TokenPayload
    {
        public string LoggedInName { get; set; }
        public string ClientIp { get; set; }
        public string Message { get; set; }
        public Guid UserGuid { get; set; }
        public int ExpireTimeInMins { get; set; }
    }
}
