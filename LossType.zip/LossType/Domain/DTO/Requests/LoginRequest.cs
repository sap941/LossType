﻿using System;
using System.ComponentModel.DataAnnotations;

namespace LossType.Domain.DTO.Requests
{
    public class LoginRequest
    {
        [Required]
        public string UserName { get; set; }
        public string Password { get; set; }
        public DateTime? TokenCreationTime { get; set; }
        public LoginReason LoginRequestReason { get; set; }
    }

    public enum LoginReason { LOGIN, REFRESH_TOKEN, CREATE_PASSWORD, FORGOT_PASSWORD }
   
}
