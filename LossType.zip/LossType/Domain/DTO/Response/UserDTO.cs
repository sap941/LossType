﻿using System;
using System.Text.Json.Serialization;

namespace LossType.Domain.DTO.Response
{
    public class UserDto : ICloneable
    {
        public Guid UserGuid { get; set; }
        public string LoggedInName { get; set; }
        public string ErrorMessage { get; set; }
        public bool IsAllowLogin { get; set; }
        public string Expiration { get; set; }
        public long ExpirationInMinutes { get; set; }
        public string JWTToken { get; set; }
        [JsonIgnore]
        public string UserPasswordEncrypted { get; set; }
        
        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
