﻿using LossType.Domain.DTO.Requests;
using LossType.Domain.DTO.Response;
using System.Threading.Tasks;

namespace LossType.Repositories.Interfaces
{
    public interface ILoginRepository
    {
        public Task<UserDto> ValidateUser(LoginRequest request);
        
    }
}
