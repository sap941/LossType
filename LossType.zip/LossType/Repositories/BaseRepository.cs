﻿using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.EntityFrameworkCore;
using NLog;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;

namespace LossType.Repositories
{
    public class BaseRepository //: IGenericRepository
    {
        /// <summary>
        /// The database connection
        /// </summary>
        private readonly LossTypeContext _context;
        private ILogger _logger = null;
        private IActionContextAccessor _accessor;
        private Stopwatch timer = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseRepository" /> class.
        /// </summary>
        /// <param name="LossTypeContext">The database connection.</param>
        public BaseRepository(LossTypeContext context, IActionContextAccessor accessor)
        {
            _context = context;
            _logger = LogManager.GetCurrentClassLogger();
            _accessor = accessor;
            
        }       
        protected SqlParameter[] AddSearchPrams(string name, object value, SqlParameter[] param, SqlDbType type)
        {
            var prameter = new SqlParameter()
            {
                ParameterName = name,
                SqlDbType = type,
                Direction = ParameterDirection.Input,
                Value = value
            };
            param = param.Concat(new SqlParameter[] { prameter }).ToArray();
            return param;
        }

        #region DB Operations
        public bool ReaderHasRows { get; set; }
        public bool IsConnectionOpen { get; set; }
        
        protected DbCommand GetCommand(string procName, SqlParameter[] parameters, int timeOut = 100)
        {
            using (var command = _context.Database.GetDbConnection().CreateCommand())
            {
                command.CommandTimeout = timeOut;
                command.CommandText = procName;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddRange((SqlParameter[])parameters.Clone());
                return command;
            }
        }
        protected DbCommand GetCommand(int timeOut = 100)
        {
            using (var command = _context.Database.GetDbConnection().CreateCommand())
            {
                command.CommandTimeout = timeOut;
                return command;
            }
        }
        protected object ExecuteScalar(string procName, SqlParameter[] parameters)
        {
            if (procName == null || parameters == null) return null;

            OpenConnection();
            using (var command = GetCommand(procName, parameters))
            {
                if (command == null) return null;
                var value = command.ExecuteScalar();
                command.Parameters.Clear();
                CloseConnection();

                return value;
            }
        }
        protected void OpenConnection()
        {
            this._context.Database.OpenConnection();
            IsConnectionOpen = true;
        }
        protected void CloseConnection()
        {
            if (IsConnectionOpen)
            {
                this._context.Database.CloseConnection();
                IsConnectionOpen = false;
            }
        }
        protected void CloseReader(DbDataReader reader)
        {
            if (!reader.IsClosed)
            {
                reader.Close();
            }
        }
        #endregion

        
    }
}
