﻿using LossType.Domain.DTO.Requests;
using LossType.Domain.DTO.Response;
using LossType.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace LossType.Repositories.Login
{
    public class LoginRepository : BaseRepository, ILoginRepository
    {
        private readonly ILogger<LoginRepository> _logger;
        private readonly LossTypeContext _context;
        public LoginRepository(LossTypeContext context,

            IActionContextAccessor accessor) : base(context, accessor)
        {
            _context = context;
        }
        public async Task<UserDto> ValidateUser(LoginRequest loginRequest)
        {
            string message = string.Empty;
            UserDto validatedUser = new UserDto();
            //Validate user from the DB by sending a query command for the Login Request
            
            return await Task.Run(() => validatedUser);
        }
        
    }
}
