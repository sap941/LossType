﻿using LossType.Common;
using Microsoft.EntityFrameworkCore;
using System;

namespace LossType.Repositories
{
    public partial class LossTypeContext : DbContext
    {
        public LossTypeContext() { }
        public LossTypeContext(DbContextOptions<LossTypeContext> options) : base(options) { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer(Utilities.ConnectionString,
                    sqlServerOptionsAction: SqlOptions =>
                    SqlOptions.EnableRetryOnFailure(
                        maxRetryCount: 10,
                        maxRetryDelay: TimeSpan.FromSeconds(30),
                        errorNumbersToAdd: null));
            }
        }
    }
}
