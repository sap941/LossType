﻿using LossType.Domain.DTO.Requests;
using LossType.Domain.DTO.Response;
using System.Threading.Tasks;

namespace LossType.Framework.JWTWebToken
{
    public enum TokenType
    {
        Authorization = 1,
        Authentication = 2
    }
    public interface ITokenOperations
    {
        public Task<TokenPayload> ReadJwtToken(string jwtToken, TokenType tokenType);
        public Task<string> GenerteJwtWebToken(UserDto user, TokenType tokenType);
    }
}
