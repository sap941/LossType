﻿using LossType.Common;
using LossType.Domain.DTO.Response;
using LossType.Framework.JWTWebToken;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace LossType.Domain.DTO.Requests
{
    public class TokenOperations : ITokenOperations
    {
        private readonly ILogger<TokenOperations> _logger;
        private readonly JWTokenSettings _jwtSettings;
        private readonly string ipAddress = string.Empty;
        private readonly string endpointUri = string.Empty;

        public TokenOperations(ILogger<TokenOperations> logger, IOptions<JWTokenSettings> jwtSettings, IActionContextAccessor accessor)
        {
            _logger = logger;
            _jwtSettings = jwtSettings.Value;
            ipAddress = accessor.ActionContext != null ? accessor.ActionContext.HttpContext.Connection.RemoteIpAddress.ToString(): ipAddress;
            endpointUri = accessor.ActionContext != null ? accessor.ActionContext.HttpContext.Request.Path.ToUriComponent() : endpointUri;
        }

        public async Task<TokenPayload> ReadJwtToken(string jwtToken, TokenType tokenType)
        {
            SecurityToken securityToken = null;
            ClaimsPrincipal claims = null;

            var payload = new TokenPayload();
            var handler = new JwtSecurityTokenHandler();

            var validations = new TokenValidationParameters
            {
                ValidateIssuer = false,
                ValidateAudience = false,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_jwtSettings.AuthenticationKey)),
                ValidateLifetime = true
            };

            claims = handler.ValidateToken(jwtToken, validations, out securityToken);

            payload.UserGuid = Guid.Parse(claims.Claims.FirstOrDefault(c => c.Type == "UserGuid").Value);
            payload.ClientIp = claims.Claims.FirstOrDefault(c => c.Type == "ClientIp").Value;
            payload.ExpireTimeInMins = Convert.ToInt32(claims.Claims.FirstOrDefault(c => c.Type == "ExpireTimeInMins").Value);
            payload.LoggedInName = claims.Claims.FirstOrDefault(c => c.Type == "LoggedInName").Value;

            return await Task.Run(() => payload);
        }

        public async Task<string> GenerteJwtWebToken(UserDto user, TokenType tokenType)
        {
            var utcTimeNow = DateTime.UtcNow;
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = GetClaimsIdentity(user),
                Expires = tokenType.Equals(TokenType.Authorization) ? 
                        utcTimeNow.AddMinutes(user.ExpirationInMinutes.Equals(0)? _jwtSettings.TokenExpiryTimeInMinutes: user.ExpirationInMinutes) : 
                        utcTimeNow.AddMinutes(_jwtSettings.TokenExpiryTimeInMinutes),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_jwtSettings.AuthenticationKey)), SecurityAlgorithms.HmacSha256Signature)
            };

            user.Expiration= tokenDescriptor.Expires.GetValueOrDefault().ToString("yyyy-MM-dd hh:mm:ss tt");
            
            var token = jwtTokenHandler.CreateToken(tokenDescriptor);
            return await Task.Run(() => jwtTokenHandler.WriteToken(token));
        }

        private ClaimsIdentity GetClaimsIdentity(UserDto user)
        {
            return new ClaimsIdentity(new List<Claim>
            {
                new Claim("UserGuid", user.UserGuid.ToString()),
                new Claim("LoggedInName", user.LoggedInName),
                new Claim("ClientIp", ipAddress),
                new Claim("ExpireTimeInMins", user.ExpirationInMinutes.ToString()),
            });
        }
    }
}
