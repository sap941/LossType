﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace LossType.Framework.Base
{
    [Route("")]
    [ApiController]
    public class BaseController : ControllerBase
    {
        public BaseController()
        {

        }
        
    }
}