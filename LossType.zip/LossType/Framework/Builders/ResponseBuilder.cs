﻿using LossType.Domain.DTO.Error;
using LossType.Domnain.DTO.Response;
using LossType.Framework.Middleware;
using LossType.Framework.Middleware.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Localization;
using System;
using System.Collections.Generic;

namespace LossType.Framework.Builders
{/// <summary>
 /// 
 /// </summary>
    public class ResponseBuilder<T> : IResponseBuilder<T>
    {
        private readonly APIResponse<T> _aPIResponse;
        public ResponseBuilder()
        {
            _aPIResponse = new APIResponse<T>();
            _aPIResponse.Errors = new List<Domain.DTO.Error.Error>();
            _aPIResponse.HttpStatus = StatusCodes.Status200OK;
        }

        public ResponseBuilder<T> AddHttpStatus(int? status)
        {
            _aPIResponse.HttpStatus = status;
            return this;
        }

        public ResponseBuilder<T> AddMessage(string message)
        {
            _aPIResponse.Message = message;
            return this;
        }

        public ResponseBuilder<T> AddSuccessData(IEnumerable<T> data)
        {
            _aPIResponse.Data = data;
            this.AddMessage("Success");
            return this;
        }

        public ResponseBuilder<T> AddSuccessData(string data)
        {
            IEnumerable<string> result = new List<string>() { data };
            return AddSuccessData((IEnumerable<T>)result);
        }

        public ResponseBuilder<T> AddError(Error error)
        {
            _aPIResponse.Errors.Add(error);
            this.AddMessage("Error");
            return this;
        }

        public ResponseBuilder<T> AddError(ExceptionDetails exceptionDetails, IStringLocalizer<SharedResource> localizer)
        {
            if (exceptionDetails.ExceptionLevel.Equals(ExceptionLevel.Info))
            {
                if (exceptionDetails.ErrorMessages != null && exceptionDetails.ErrorMessages.Count > 0)
                    _aPIResponse.Errors.Add(new Error() { UserMessage = exceptionDetails.ErrorMessages[0], DevMessage = exceptionDetails.ErrorMessages[0], ErrorCode = (int)exceptionDetails.StatusCode });
                else
                    _aPIResponse.Errors.Add(new Error() { UserMessage = exceptionDetails.ErrorMessage, DevMessage = exceptionDetails.ErrorMessage, ErrorCode = (int)exceptionDetails.StatusCode });
            }
            else
            {
                _aPIResponse.Errors.Add(new Error() { UserMessage = localizer["GENERIC_USER_MESSAGE"], DevMessage = exceptionDetails.ErrorMessage, ErrorCode = (int)exceptionDetails.StatusCode });
            }
            this.AddMessage("Error");
            return this;
        }

        public ResponseBuilder<T> AddErrors(List<string> errors, IStringLocalizer<SharedResource> localizer)
        {
            foreach (string errorMessage in errors)
                _aPIResponse.Errors.Add(new Error() { UserMessage = localizer["REQUEST_HEADER_INVALID"], DevMessage = errorMessage, ErrorCode = StatusCodes.Status400BadRequest });
            //_aPIResponse.Errors.AddRange(errors);
            this.AddMessage("Error");
            return this;
        }

        public APIResponse<T> Build()
        {
            _aPIResponse.ApiResponseStatus = (_aPIResponse.Data != null && _aPIResponse.Errors.Count == 0)
                ? ResponseStatus.OK.ToString()
                : ResponseStatus.Failed.ToString();
            return _aPIResponse;
        }

        public ResponseBuilder<T> AddSuccessData(T data)
        {
            IEnumerable<T> result = new List<T>() { data };
            return AddSuccessData(result);
        }

        public enum ResponseStatus
        {
            OK,
            Failed
        }
    }
}
