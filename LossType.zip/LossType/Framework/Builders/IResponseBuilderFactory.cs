﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LossType.Framework.Builders
{
    public interface IResponseBuilderFactory
    {
        /// <summary>
        /// Gets the builder.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        IResponseBuilder<T> GetBuilder<T>();
    }
}
