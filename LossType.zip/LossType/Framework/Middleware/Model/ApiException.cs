﻿using System;
using System.Collections.Generic;
using System.Net;

namespace LossType.Framework.Middleware.Model
{
    public class ApiException : Exception
    {
        public ExceptionDetails ExceptionDetails { get; set; }
        public ApiException(ExceptionDetails exceptionDetails) : base(exceptionDetails.ToString())
        {
            ExceptionDetails = exceptionDetails;
        }
    }

    public enum ExceptionLevel { Error, Warning, Info };

    public class ExceptionDetails
    {
        public HttpStatusCode StatusCode { get; set; }
        public string ErrorMessage { get; set; }
        public List<string> ErrorMessages { get; set; }
        public object Result { get; set; }
        public ExceptionLevel ExceptionLevel { get; set; }
        public override string ToString()
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(this);
        }
    }
}
