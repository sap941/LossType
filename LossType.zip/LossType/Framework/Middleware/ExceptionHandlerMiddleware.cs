﻿using LossType.Framework.Builders;
using LossType.Framework.Middleware.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Net;
using System.Threading.Tasks;

namespace LossType.Framework.Middleware
{
    public class ExceptionHandlerMiddleware
    {
        private readonly ILogger<ExceptionHandlerMiddleware> _logger = null;
        private readonly RequestDelegate _next = null;
        private readonly IStringLocalizer<SharedResource> _localizer;
        public ExceptionHandlerMiddleware(RequestDelegate next,
            ILogger<ExceptionHandlerMiddleware> logger, IStringLocalizer<SharedResource> localizer)
        {
            _next = next;
            _logger = logger;
            _localizer = localizer;
        }
        public async Task Invoke(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                OnException(httpContext, ex);
            }
        }
        private void OnException(HttpContext context, Exception exception)
        {
            var exceptionType = exception.GetType();
            ExceptionDetails exceptionDetails = new ExceptionDetails();
            if (exceptionType == typeof(UnauthorizedAccessException))
            {
                exceptionDetails.ErrorMessage = _localizer["UNAUTHORIZED_ACCESS"];
                exceptionDetails.StatusCode = HttpStatusCode.Unauthorized;
                exceptionDetails.ExceptionLevel = ExceptionLevel.Error;
            }
            else if (exceptionType == typeof(NotImplementedException))
            {
                exceptionDetails.ErrorMessage = _localizer["SERVER_ERROR_OCCURED"];
                exceptionDetails.StatusCode = HttpStatusCode.NotImplemented;
                exceptionDetails.ExceptionLevel = ExceptionLevel.Error;
            }

            else if (exceptionType == typeof(ApiException))
            {
                ApiException apiException = ((ApiException)exception);
                exceptionDetails = apiException.ExceptionDetails;
            }
            else
            {
                exceptionDetails.StatusCode = HttpStatusCode.InternalServerError;
                exceptionDetails.ErrorMessage = exception.Message;
                exceptionDetails.ExceptionLevel = ExceptionLevel.Error;
            }


            if (exceptionDetails.ExceptionLevel.Equals(ExceptionLevel.Error))
                _logger.LogError("Error Message : " + exceptionDetails.ErrorMessage);
            else if (exceptionDetails.ExceptionLevel.Equals(ExceptionLevel.Warning))
                _logger.LogWarning("Error Message : " + exceptionDetails.ErrorMessage);
            else if (exceptionDetails.ExceptionLevel.Equals(ExceptionLevel.Info))
                _logger.LogInformation("Error Message : " + exceptionDetails.ErrorMessage);
            //context.ExceptionHandled = true;
            _logger.LogTrace("Inner Exception if any :" + exception.InnerException);
            _logger.LogTrace("StackTrace :" + exception.StackTrace);

            var response = context.Response;
            context.Response.StatusCode = 200;
            context.Response.ContentType = "application/json";

            var serializeResult =
            JsonConvert.SerializeObject(
            new ResponseBuilder<object>().AddHttpStatus((int)exceptionDetails.StatusCode).AddError(exceptionDetails, _localizer).Build(),
            new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
            response.ContentType = "application/json";
            response.WriteAsync(serializeResult).ToString();
        }
    }

    public class SharedResource
    {
        //This empty class is required for the IStringLocalizer interface.
    }
}

